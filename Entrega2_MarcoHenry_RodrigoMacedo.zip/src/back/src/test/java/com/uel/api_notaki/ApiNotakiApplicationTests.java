package com.uel.api_notaki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiNotakiApplicationTests {

	@Test
	void contextLoads() {
	}

}
