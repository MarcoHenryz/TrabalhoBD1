package com.uel.enums;

public enum Dificuldade {
    FACIL,
    MEDIO,
    DIFICIL
}
