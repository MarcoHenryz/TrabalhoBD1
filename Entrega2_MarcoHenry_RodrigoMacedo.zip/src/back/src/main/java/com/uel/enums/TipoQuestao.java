package com.uel.enums;

public enum TipoQuestao {
    MULTIPLA_ESCOLHA,
    VOUF,
    DISSERTATIVA
}
