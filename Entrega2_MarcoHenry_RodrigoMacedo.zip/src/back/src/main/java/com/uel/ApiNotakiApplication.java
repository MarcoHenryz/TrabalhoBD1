package com.uel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiNotakiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiNotakiApplication.class, args);
	}

}
