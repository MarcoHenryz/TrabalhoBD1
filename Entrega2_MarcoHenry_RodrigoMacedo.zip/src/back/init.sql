CREATE TABLE IF NOT EXISTS usuarios (
    id UUID PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    salt VARCHAR(64) NOT NULL,
    hash_senha VARCHAR(100) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS alunos (
    id UUID PRIMARY KEY,
    matricula VARCHAR(50) UNIQUE NOT NULL,
    media NUMERIC(5,2) NOT NULL DEFAULT 0,
    data_inicio DATE NOT NULL,
    data_conclusao DATE,
    usuario_id UUID NOT NULL UNIQUE REFERENCES usuarios(id) ON DELETE CASCADE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS professores (
    id UUID PRIMARY KEY,
    area VARCHAR(100) NOT NULL,
    usuario_id UUID NOT NULL UNIQUE REFERENCES usuarios(id) ON DELETE CASCADE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS avaliacoes (
    id UUID PRIMARY KEY,
    descricao TEXT NOT NULL,
    data DATE NOT NULL,
    horario TIME NOT NULL,
    professor_id UUID REFERENCES professores(id) ON DELETE SET NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS avaliacao_alunos (
    avaliacao_id UUID REFERENCES avaliacoes(id) ON DELETE CASCADE,
    aluno_id UUID REFERENCES alunos(id) ON DELETE CASCADE,
    nota NUMERIC(5,2),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (avaliacao_id, aluno_id)
);

CREATE TABLE IF NOT EXISTS questoes (
    questao_id UUID PRIMARY KEY,
    enunciado TEXT NOT NULL,
    tema VARCHAR(30) NOT NULL,
    tipo VARCHAR(50) NOT NULL CHECK (tipo IN ('MULTIPLA_ESCOLHA','DISSERTATIVA','VOUF')),
    dificuldade VARCHAR(30) NOT NULL CHECK (dificuldade IN ('FACIL', 'MEDIO', 'DIFICIL')),
    resposta_esperada TEXT,
    professor_id UUID REFERENCES professores(id) ON DELETE SET NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS alternativas (
    id UUID PRIMARY KEY,
    questao_id UUID NOT NULL REFERENCES questoes(questao_id) ON DELETE CASCADE,
    alternativa TEXT NOT NULL,
    verdadeiro BOOLEAN NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vouf (
    id UUID PRIMARY KEY,
    item TEXT NOT NULL,
    verdadeiro BOOLEAN NOT NULL,
    questao_id UUID NOT NULL REFERENCES questoes(questao_id) ON DELETE CASCADE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS avaliacao_questoes (
    avaliacao_id UUID NOT NULL REFERENCES avaliacoes(id) ON DELETE CASCADE,
    questao_id UUID NOT NULL REFERENCES questoes(questao_id) ON DELETE CASCADE,
    peso NUMERIC(5,2) NOT NULL DEFAULT 1.00,
    ordem INTEGER NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (avaliacao_id, questao_id)
);

CREATE TABLE IF NOT EXISTS respostas_alunos (
    id UUID PRIMARY KEY,
    avaliacao_id UUID NOT NULL,
    aluno_id UUID NOT NULL,
    questao_id UUID NOT NULL,
    
    alternativa_escolhida_id UUID REFERENCES alternativas(id) ON DELETE SET NULL,
    
    vouf_item_id UUID REFERENCES vouf(id) ON DELETE SET NULL,
    vouf_resposta BOOLEAN,
    
    resposta_texto TEXT,
    
    nota NUMERIC(5,2),
    
    respondido_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    corrigido BOOLEAN DEFAULT FALSE,
    
    FOREIGN KEY (avaliacao_id, aluno_id) REFERENCES avaliacao_alunos(avaliacao_id, aluno_id) ON DELETE CASCADE,
    FOREIGN KEY (avaliacao_id, questao_id) REFERENCES avaliacao_questoes(avaliacao_id, questao_id) ON DELETE CASCADE
);



